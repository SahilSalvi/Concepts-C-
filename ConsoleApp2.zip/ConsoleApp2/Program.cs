﻿using System;
using pract.testing;
class Program
{

    public static void Main()
    {
        test.Print();

        int total = 0;
        // int product = 0;
        Calculator(10, 20, out total, out int Product);
        Console.WriteLine("Sum = {0} && Product = {1}", total, Product);

        int i = 0;

        SimpleMethod(ref i);         
        Console.WriteLine(i);



        int[] Numbers = new int[3];
        Numbers[0] = 101;
        Numbers[1] = 102;
        Numbers[2] = 103;
        ParamsMethod();
        ParamsMethod(Numbers);
        ParamsMethod(1, 2, 3, 4, 4);

    }
    public static void SimpleMethod(ref int j)  // both ref
    {
        j = 101;
    }

    public static void Calculator(int FN, int SN, out int Sum, out int Product)
    {
        Sum = FN + SN;
        Product = FN * SN;
    }
    public static void ParamsMethod(params int[] Numbers)
    {
        Console.WriteLine("There are {0} elements", Numbers.Length);
        foreach (int i in Numbers)
        {
            Console.WriteLine(i);
        }
    } }


namespace pract
                {
                     namespace testing
                     {
                         class test
                         {
                                public static void Print()
                                {
                                Console.WriteLine("Hello bro you did the namespace thing SUCCESSFULLY!");
                                }
                    
                         }
                     }
                }
    



