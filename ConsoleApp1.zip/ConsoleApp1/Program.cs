﻿using System;

namespace ConsoleApp1
{
    class Program
    {

        static void Main()
        {
            practice2();   //just change the suffix numbers for getting different outputs for code. eg: practice3, practice, practice5.





            //Program.EvenNumbers(41);                    //for calling static method.

            // Program p = new Program(); p.OddNumber();  // for calling non-static menthod
        }
        

        public static void EvenNumbers(int Target)
        {
            int start = 0;
            while (start <= Target)
            {
                Console.WriteLine(start);
                start = start + 2;
            }
        }
        public void OddNumber() // the code is for even number
        {
            int num = 0;
            while (num <= 10)
            {
                Console.WriteLine(num);
                num = num + 3;
                num++;
                
            }
        }
        static void practice()
        {
            Console.WriteLine("welcome please enter your first name.");

            String Firstname = Console.ReadLine();

            Console.WriteLine("Write your last name.");
            String Lastname = Console.ReadLine();


            Console.WriteLine("Hello {0} {1}", Firstname, Lastname);

            //Console.WriteLine("Hello " + username + "!");

        }
        static void practice1()
        {
            int i = 0;
            Console.WriteLine("Min = {0}", int.MinValue);
            Console.WriteLine("Max = {0}", int.MaxValue);
            double d = 123.42341;                
            Console.WriteLine(d);                    


        }
        static void practice2()
        {   //string
            string name = "\"Sahil\n";
            string name1 = "One\nTwo\nThree\n"; 
            string name2 = "C:\\pragia\\dotnet\\training\\csharp\n";
            string name3 = @"C:\\pragia\\dotnet\\training\\csharp";  //adding  a "@" makes the sentence read as it without any escap sequences like above.
            string name4 = @"C:\pragia\dotnet\training\csharp";
            Console.WriteLine("{0}{1}{2}{3}{4}", name, name1, name2, name3, name4);

        }
        static void practice3()
        {
            int Number = 15;
            bool IsNumber10 = Number == 10 ? true : false;
            Console.WriteLine("Number ==10 is {0}", IsNumber10);
        }
        static void practice4()//how to use null for int 
        {
            int? TicketsOnSale = null; //try changing it to 100 for getting another value

            int AvailableTickets;

            if (TicketsOnSale == null)
            {
                AvailableTickets = 0;

            }
            else {
                AvailableTickets = (int)TicketsOnSale;// could also use .value in the end of Tickets on sale
            }
            Console.WriteLine("AvailableTickets = {0}", AvailableTickets);

        }
        static void practice5()//conversion & parse
        {
            int i = 123;//implicit
            float f = i;
            Console.WriteLine(f);

            float fl = 1234.34325f;//explicit
            int ii = Convert.ToInt32(fl);
            Console.WriteLine(ii);

            string strnumber = "100";
            int j = int.Parse(strnumber);
            Console.WriteLine(j);              //parse converts string value(only numbers) through a int a value 32 bit.

            string strNumber = "100TG";//try removing alphabet.
            int Result = 0;
            bool IsConversionSuccessful = int.TryParse(strNumber, out Result);
            if (IsConversionSuccessful)       //Parse()throws exception if cannot parse value
            {                                 //Parse()returns a bool indicating whether it succeedd or failed.
                Console.WriteLine(Result);
            }
            else
            {
                Console.WriteLine("Please enter a valid Number");
            }
        }
        static void practice6()//array
        {
            int[] EvenNumber = new int[3];
            EvenNumber[0] = 0;
            EvenNumber[1] = 2;
            EvenNumber[2] = 4;
            Console.WriteLine(EvenNumber[2]);


        }
        /// <summary>
        /// Trailer of creation for xml doc. Jst /// use this and enter out side class
        /// </summary>
        static void practice7() //switch case
        {

            Console.WriteLine("Please choose one number from 1 or 0");
            int i = int.Parse(Console.ReadLine());

            Console.WriteLine("Please enter a number");
            int UserNumber = int.Parse(Console.ReadLine());

            if (i == 0)
            {

                switch (UserNumber)
                {
                    case 10:
                        Console.WriteLine("Your number is 10");
                        break;
                    case 20:
                        Console.WriteLine("Your number is 20");
                        break;
                    case 30:
                        Console.WriteLine("Your number is 30");
                        break;
                    default:
                        Console.WriteLine("Your number is not 10,20,30");
                        break;

                }
            }
            else if (i == 1)
            {
                switch(UserNumber)
                {
                    case 10:
                    case 20:
                    case 30:
                        Console.WriteLine("Your number is {0}", UserNumber);
                        break; 
                   default:
                        Console.WriteLine("Your number is not 10,20,30");
                        break;


                }
            }
           
        }
        /// <summary>
        /// Coffee Shop
        /// </summary>
        static void practice8() //switch case
        {
            int TotalCoffeeCost = 0;
            Start:
            Console.WriteLine("Please select you coffee size : 1-Small, 2-Medium, 3-Large");
            int UserChoice = int.Parse(Console.ReadLine());

            switch(UserChoice)
            {
                case 1:
                    TotalCoffeeCost += 1;
                    break;
                case 2:
                    TotalCoffeeCost += 2;
                    break;
                case 3:
                    TotalCoffeeCost += 3;
                    break;
            }
            Decide:
            Console.WriteLine("Do you want to buy another coffee - Yes or No");
            string UserDecision = Console.ReadLine();
            switch(UserDecision.ToUpper())
            {
                
                case "YES":
                    goto Start;
                case "NO":
                    break;
                default:
                    Console.WriteLine("Your choice is {0} invalid, please try again ", UserDecision);
                    goto Decide;
            }
            Console.WriteLine("Thankyou for shopping with us");
            Console.WriteLine("Your Bill Amount is {0}", TotalCoffeeCost);
        }
        static void practice9() // While loop
        {
            Console.WriteLine("Enter a number");
            int usernumber = int.Parse(Console.ReadLine());

            int start = 0;

            while (start <= usernumber) 
            {
                Console.Write(start + " ");
                start += 2;
            }
        }
        static void practice10()//Do while 
        {
            string UserChoice;
            do
            {
                Console.WriteLine("Please enter your target");
                int UserTarget = int.Parse(Console.ReadLine());

                int start = 0;

                while (start <= UserTarget)
                {
                    Console.Write(start + " ");
                    start = start + 2;

                }
                do
                {
                    Console.WriteLine("Do you want to continue - Yes or No?");
                    UserChoice = Console.ReadLine().ToUpper();
                    if (UserChoice != "Yes" && UserChoice != "No") ;
                    {
                        Console.WriteLine("Invalid Choice, Please say yes or no");

                    }


                } while (UserChoice != "Yes" && UserChoice != "No");

            } while (UserChoice == "Yes");
        
        }
        static void practice11()//for loop & for each loop
        {
            for (int i = 0; i <= 20; i++)                 
            {
                if (i % 2 == 1)
                    continue;
                Console.WriteLine(i);
            }
        }
        static void practice12()//for loop & for each loop
        { 
             int[] Numbers = new int[4];
            Numbers[0] = 101;
            Numbers[1] = 102;
            Numbers[2] = 103;
            Numbers[3] = 104;

            for (int j = 0; j < Numbers.Length; j++)
            {
                Console.WriteLine(Numbers[j]);
            }

            foreach (int k in Numbers) //try removing the number[3] it will build successfully but their error of
            {
                Console.WriteLine(k);
            }

            int i = 0;
            while (i < Numbers.Length)
            {
                Console.WriteLine(Numbers[i]);
                i++;
            }
         }
        
        
        

    }
}
